# סורק מניות (Netlify)

אפליקציה ללא Base44 וללא התחברות. כל מבקר מזין את מפתחות Alpaca שלו בהגדרות (גלגל שיניים).
המפתחות, רשימות המניות וההתראות נשמרים ב-localStorage של הדפדפן שלו בלבד.
הסריקה והמחירים רצים ב-Netlify Functions (`netlify/functions`), והמפתחות נשלחים אליהן בכל בקשה.

## פריסה
1. מעלים את התיקייה ל-GitHub (repository חדש).
2. ב-Netlify: Add new site → Import an existing project → בוחרים את ה-repo.
   ההגדרות נקראות אוטומטית מ-`netlify.toml` (build: `npm run build`, publish: `dist`).
3. Deploy. אין צורך במשתני סביבה.

הערה: גרירת תיקיית `dist` בלבד לא תעבוד, כי היא לא כוללת את הפונקציות.

## הרצה מקומית
`npm install` ואז `npx netlify dev`
