// Cloudflare Worker entry: serves /api/* from the shared handlers.
// Everything else is served as static files from ./dist (see wrangler.toml).
import scanStocks from "./netlify/functions/scanStocks.ts";
import livePrices from "./netlify/functions/livePrices.ts";
import systemStatus from "./netlify/functions/systemStatus.ts";

const routes: Record<string, (req: Request) => Promise<Response>> = {
  scanStocks,
  livePrices,
  systemStatus,
};

export default {
  async fetch(request: Request, env: { ASSETS: { fetch: (r: Request) => Promise<Response> } }) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api/")) {
      const handler = routes[url.pathname.slice(5)];
      if (!handler) return Response.json({ error: "Not found" }, { status: 404 });
      if (request.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
      return handler(request);
    }
    return env.ASSETS.fetch(request);
  },
};
