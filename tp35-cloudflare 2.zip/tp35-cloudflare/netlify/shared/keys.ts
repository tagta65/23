// Alpaca keys come from the visitor's own browser, sent per request in headers.
export function getKeys(req: Request) {
  return {
    apiKey: req.headers.get("x-alpaca-key") || "",
    secretKey: req.headers.get("x-alpaca-secret") || "",
  };
}

export const MISSING_KEYS = "חסרים מפתחות בורסה - פתח את ההגדרות (סמל הגלגל) והזן אותם";
