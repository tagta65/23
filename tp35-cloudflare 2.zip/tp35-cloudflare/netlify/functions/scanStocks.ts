import { fetchBars } from "../shared/market.ts";
import { getKeys, MISSING_KEYS } from "../shared/keys.ts";
import { BARS_NEEDED, scanP402, scanVixFix, scanAnalog, scanSmc, scanOrderFlow, scanMtfFlow, ORDERFLOW_SIGNALS } from "../shared/scanAlgos.ts";
import { analyze as analyzeMrktEdge } from "../shared/mrktEdge.ts";

const SCANNERS = { p402: scanP402, vixfix: scanVixFix, analog: scanAnalog, smc: scanSmc, orderflow: scanOrderFlow };
const toEngineBars = (bars) => (bars || []).map((b) => ({
  ...b,
  t: typeof b.t === "number" ? b.t : Date.parse(b.t),
  date: b.date || new Date(b.t).toISOString().slice(0, 10),
}));

export default async function (req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const algo = ["p402", "vixfix", "analog", "smc", "orderflow", "mtfflow", "mrktedge"].includes(body.algo) ? body.algo : null;
    const timeframe = ["15", "30", "60", "120", "240", "D", "W"].includes(body.timeframe) ? body.timeframe : null;
    if (!algo || !timeframe) return Response.json({ error: "Invalid parameters" }, { status: 400 });
    const list = (Array.isArray(body.symbols) ? body.symbols : [])
      .filter((t) => t && typeof t.symbol === "string" && /^[A-Za-z.\-]{1,10}$/.test(t.symbol))
      .slice(0, 12)
      .map((t) => ({ symbol: t.symbol, name: String(t.name || t.symbol) }));
    if (!list.length) return Response.json({ error: "Invalid parameters" }, { status: 400 });

    const { apiKey, secretKey } = getKeys(req);
    if (!apiKey || !secretKey) return Response.json({ error: MISSING_KEYS }, { status: 400 });

    const scanFn = SCANNERS[algo];
    const barsCount = BARS_NEEDED[algo];
    const alertTf = algo === "mtfflow" || algo === "mrktedge" ? "D" : timeframe;
    const analysisTimeframe = algo === "mrktedge" ? "D" : timeframe;

    // Live last-trade prices in a single batch call (IEX is real-time on this plan)
    let liveTrades = null;
    try {
      const symbols = list.map((t) => t.symbol).join(",");
      const res = await fetch(
        `https://data.alpaca.markets/v2/stocks/trades/latest?symbols=${symbols}&feed=iex`,
        { headers: { "APCA-API-KEY-ID": apiKey, "APCA-API-SECRET-KEY": secretKey } }
      );
      if (res.ok) liveTrades = (await res.json()).trades || null;
    } catch (err) {
      // best-effort - bars are still used if live quotes fail
    }

    let mrktContext = { spy: null, qqq: null, vix: null };
    if (algo === "mrktedge") {
      const [spy, qqq] = await Promise.all([
        fetchBars("SPY", "D", barsCount, apiKey, secretKey),
        fetchBars("QQQ", "D", barsCount, apiKey, secretKey),
      ]);
      mrktContext = { spy: toEngineBars(spy), qqq: toEngineBars(qqq), vix: null };
    }

    const results = [];
    // The chunk is small (browser sends a few symbols per call), so run all of it in
    // parallel. A time budget keeps us under the platform timeout.
    const deadline = Date.now() + 8000;
    const settled = await Promise.all(list.map(async (t) => {
      try {
        const trade = liveTrades ? liveTrades[t.symbol] : null;
        const applyLive = (bars) => {
          if (bars.length && trade && trade.p) {
            const last = bars[bars.length - 1];
            last.c = trade.p;
            last.h = Math.max(last.h, trade.p);
            last.l = Math.min(last.l, trade.p);
          }
        };
        let data = null;
        let liveBars = null;
        // one retry with a wider window before giving up on this symbol
        for (let attempt = 0; attempt < 2 && !data && !liveBars; attempt++) {
          if (attempt > 0 && deadline - Date.now() < 3500) break; // not enough time left for a retry
          const count = barsCount * (attempt + 1);
          if (algo === "mtfflow") {
            const [barsL, barsH] = await Promise.all([
              fetchBars(t.symbol, "240", count, apiKey, secretKey),
              fetchBars(t.symbol, "D", count, apiKey, secretKey),
            ]);
            applyLive(barsL);
            applyLive(barsH);
            if (barsL.length >= 60 && barsH.length >= 60) {
              const cutL = barsL.slice(-55);
              const cutH = barsH.slice(-55);
              data = scanMtfFlow(cutL, cutH);
              // compact bars for real-time client-side recompute on every price tick
              liveBars = {
                l: cutL.map(({ h, l, c, v }) => ({ h, l, c, v })),
                h: cutH.map(({ h, l, c, v }) => ({ h, l, c, v })),
              };
            }
          } else if (algo === "mrktedge") {
            const [dailyRaw, hourlyRaw] = await Promise.all([
              fetchBars(t.symbol, "D", count, apiKey, secretKey),
              fetchBars(t.symbol, "60", 600, apiKey, secretKey),
            ]);
            const daily = toEngineBars(dailyRaw);
            const hourly = toEngineBars(hourlyRaw);
            applyLive(daily);
            if (daily.length >= 250) data = analyzeMrktEdge(daily, { ...mrktContext, hourly });
          } else {
            const bars = await fetchBars(t.symbol, analysisTimeframe, count, apiKey, secretKey);
            applyLive(bars);
            if (bars.length >= 30) data = scanFn(bars);
          }
        }
        return { symbol: t.symbol, name: t.name, data, liveBars };
      } catch (err) {
        return { symbol: t.symbol, name: t.name, data: null };
      }
    }));
    results.push(...settled);
    // Log positive setups as alerts (best-effort, deduped per symbol within 24h)
    const POSITIVE = {
      p402: (d) => (d.squeezeReady ? "סקוויז מוכן" : null),
      vixfix: (d) => (d.buySignal ? "איתות קנייה" : null),
      analog: (d) => (d.analogPct >= 58 ? "אנלוג חיובי" : null),
      smc: (d) => (d.above200 ? "מעל ממוצע 200" : null),
      orderflow: (d) => (d.signal > 0 ? (ORDERFLOW_SIGNALS[d.signal] || "איתות חיובי") : null),
      mtfflow: (d) => (["STRONG BUY", "BUY PULLBACK", "EARLY BUY"].includes(d.signal) ? d.signal : null),
      mrktedge: (d) => (["BUY", "LONG BIAS", "SELL", "SHORT BIAS"].includes(d.signal) ? d.signal : null),
    };
    // positive setups are returned to the browser, which logs them (deduped) locally
    const alerts = results
      .filter((r) => r.data && POSITIVE[algo](r.data))
      .map((r) => ({
        algo,
        symbol: r.symbol,
        timeframe: alertTf,
        signal: POSITIVE[algo](r.data),
        price: r.data.price ?? null,
      }));

    return Response.json({ results, alerts, scannedAt: new Date().toISOString() });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}
