import db from "@/api/localDb";

import React, { useState, useEffect } from "react";
import { ArrowRight, Bell, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";

const ALGOS = [
  { id: "all", label: "הכל" },
  { id: "p402", label: "P402" },
  { id: "vixfix", label: "Vix Fix" },
  { id: "analog", label: "Analog" },
  { id: "smc", label: "SMC" },
  { id: "orderflow", label: "Order Flow" },
  { id: "mtfflow", label: "MTF Flow" },
];

const TF_LABEL = {
  "15": "15ד", "30": "30ד", "60": "1ש", "120": "2ש", "240": "4ש",
  D: "יומי", W: "שבועי",
};

const ALGO_CLS = {
  p402: "border-emerald-800 bg-emerald-950/60 text-emerald-300",
  vixfix: "border-teal-800 bg-teal-950/60 text-teal-300",
  analog: "border-amber-700 bg-amber-950/60 text-amber-300",
  smc: "border-sky-800 bg-sky-950/60 text-sky-300",
  orderflow: "border-fuchsia-800 bg-fuchsia-950/60 text-fuchsia-300",
  mtfflow: "border-cyan-800 bg-cyan-950/60 text-cyan-300",
};

export default function ScannerAlerts() {
  const [alerts, setAlerts] = useState(null);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    db.entities.ScanAlert.list("-created_date", 200)
      .then(setAlerts)
      .catch(() => setAlerts([]));
    const unsubscribe = db.entities.ScanAlert.subscribe((event) => {
      if (event.type === "create") {
        setAlerts((prev) => (prev ? [event.data, ...prev] : prev));
      }
    });
    return unsubscribe;
  }, []);

  const filtered = alerts
    ? alerts.filter((a) => filter === "all" || a.algo === filter)
    : [];

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-950 to-slate-900 text-slate-100"
    >
      <div className="mx-auto max-w-3xl space-y-5 px-4 py-6 sm:py-10">
        <div className="flex items-center gap-3">
          <Link
            to="/"
            className="rounded-lg border border-slate-800 bg-slate-900 p-2 text-slate-300 hover:bg-slate-800"
            title="חזרה לסורק"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="flex items-center gap-2 font-heading text-2xl font-bold text-slate-50 sm:text-3xl">
              <Bell className="h-6 w-6 text-emerald-400" />
              התראות סורק
            </h1>
            <p className="mt-1 text-sm text-slate-400">
              היסטוריית האיתותים החיוביים שנקלטו אוטומטית מכל ארבעת האלגוריתמים.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {ALGOS.map((a) => (
            <button
              key={a.id}
              onClick={() => setFilter(a.id)}
              className={`rounded-full px-4 py-1.5 text-xs font-semibold transition-colors ${
                filter === a.id
                  ? "bg-emerald-500 text-slate-950"
                  : "border border-slate-800 bg-slate-900 text-slate-400 hover:bg-slate-800"
              }`}
            >
              {a.label}
            </button>
          ))}
        </div>

        {alerts === null ? (
          <div className="flex items-center justify-center gap-3 rounded-2xl border border-slate-800 bg-slate-900/60 px-4 py-16 text-slate-300">
            <Loader2 className="h-5 w-5 animate-spin text-emerald-400" />
            טוען התראות...
          </div>
        ) : filtered.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-800 bg-slate-900/40 px-6 py-16 text-center text-slate-400">
            <Bell className="mx-auto h-10 w-10 text-slate-600" />
            <p className="mt-3">
              {alerts.length === 0
                ? "אין עדיין התראות — הן יישמרו כאן אוטומטית כשהסורק יזהה איתות חיובי."
                : "אין התראות בקטגוריה הזו."}
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((a) => (
              <div
                key={a.id}
                className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/60 px-3 py-2"
              >
                <span className="font-semibold text-slate-100">{a.symbol}</span>
                <span
                  className={`rounded-full border px-2 py-0.5 text-[11px] font-semibold ${ALGO_CLS[a.algo] || "border-slate-700 bg-slate-900 text-slate-300"}`}
                >
                  {ALGOS.find((x) => x.id === a.algo)?.label || a.algo}
                </span>
                <span className="rounded-full border border-slate-700 bg-slate-900 px-2 py-0.5 text-[11px] text-slate-400">
                  {TF_LABEL[a.timeframe] || a.timeframe}
                </span>
                <span className="flex-1 text-sm text-emerald-300">{a.signal}</span>
                {a.price != null && (
                  <span className="text-sm text-slate-300">${a.price.toFixed(2)}</span>
                )}
                <span className="text-[11px] text-slate-500">
                  {new Date(a.created_date).toLocaleString("he-IL", {
                    day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit",
                  })}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}