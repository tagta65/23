import TableShell, { Cell, fmt, NoDataRow } from "./TableShell.jsx";

const HEADERS = ["Sym", "Price", "Analog%", "MTF", "RSI", "Fund%"];

function analogCell(pct) {
  if (pct >= 70) return { cls: "rounded-md bg-[#00E676] font-bold text-slate-950" };
  if (pct >= 60) return { cls: "rounded-md bg-[#009688] font-semibold text-white" };
  if (pct <= 30) return { cls: "rounded-md bg-[#F23645] font-semibold text-white" };
  if (pct <= 40) return { cls: "rounded-md bg-[#E65100] font-semibold text-white" };
  return { cls: "rounded-md bg-amber-400 font-semibold text-slate-950" };
}

export default function AnalogTable({ results, zoom }) {
  return (
    <TableShell columns={HEADERS} zoom={zoom}>
      {results.map(({ symbol, data }) => {
        if (!data) return <NoDataRow key={symbol} symbol={symbol} cols={6} />;
        const analog = analogCell(data.analogPct);
        const mtfCls = data.mtfScore === null
          ? "rounded-md bg-slate-900/60 text-slate-500"
          : data.mtfScore > 0
            ? "rounded-md bg-[#089981]/40 text-emerald-200"
            : "rounded-md bg-[#F23645]/40 text-red-200";
        const rsiCls = data.rsi >= 70
          ? "rounded-md bg-[#F23645]/40 text-red-200"
          : data.rsi <= 30
            ? "rounded-md bg-[#089981]/40 text-emerald-200"
            : "rounded-md bg-slate-900/60 text-slate-200";
        const fundCls = data.fund === null
          ? "rounded-md bg-slate-900/60 text-slate-500"
          : data.fund >= 0
            ? "rounded-md bg-[#089981]/40 text-emerald-200"
            : "rounded-md bg-[#F23645]/40 text-red-200";
        return (
          <tr key={symbol}>
            <Cell className="rounded-md bg-slate-800/60 font-semibold text-slate-100">{symbol}</Cell>
            <Cell className="rounded-md bg-slate-900/60 text-slate-200">{fmt(data.price)}</Cell>
            <Cell className={analog.cls} title={`Analog UP · ${data.matchedCount ?? 0} התאמות · תשואה ממוצעת ${fmt(data.analogAvgReturn, 2)}%`}>
              {fmt(data.analogPct, 1)}%
            </Cell>
            <Cell className={mtfCls}>
              {data.mtfScore === null ? "-" : fmt(data.mtfScore, 0)}
            </Cell>
            <Cell className={rsiCls}>{data.rsi === null ? "-" : fmt(data.rsi, 1)}</Cell>
            <Cell className={fundCls}>
              {data.fund === null ? "-" : `${fmt(data.fund, 2)}%`}
            </Cell>
          </tr>
        );
      })}
    </TableShell>
  );
}