import { Search, Settings, SlidersHorizontal, Bell, Activity } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

const TF_LABELS = [
  { value: "15", label: "15 דק'" },
  { value: "30", label: "30 דק'" },
  { value: "60", label: "שעה" },
  { value: "120", label: "שעתיים" },
  { value: "240", label: "4 שעות" },
  { value: "D", label: "יומי" },
  { value: "W", label: "שבועי" },
];

function LiveBadge({ loading }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-800 bg-emerald-950/60 px-2.5 py-1 text-xs font-medium text-emerald-300">
      <span className="relative flex h-2 w-2">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
        <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
      </span>
      {loading ? "סורק..." : "שידור חי"}
    </span>
  );
}

function ListToggle({ list, onListChange }) {
  return (
    <div className="flex overflow-hidden rounded-lg border border-slate-700">
      <button
        onClick={() => onListChange("1")}
        className={`px-3 py-2 text-sm font-medium transition-colors ${
          list === "1" ? "bg-slate-100 text-slate-900" : "bg-slate-900 text-slate-400 hover:bg-slate-800"
        }`}
      >
        רשימה 1
      </button>
      <button
        onClick={() => onListChange("2")}
        className={`px-3 py-2 text-sm font-medium transition-colors ${
          list === "2" ? "bg-slate-100 text-slate-900" : "bg-slate-900 text-slate-400 hover:bg-slate-800"
        }`}
      >
        רשימה 2
      </button>
    </div>
  );
}

export default function ScannerHeader({
  timeframe, onTimeframeChange, search, onSearch, scannedAt, count, loading, onOpenSettings,
  list, onListChange,
}) {
  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="font-heading text-3xl font-bold tracking-tight text-slate-50 sm:text-4xl">
            סורק מניות
          </h1>
          <p className="mt-1.5 flex flex-wrap items-center gap-2 text-sm text-slate-400">
            35 מניות בכל רשימה · 7 אלגוריתמים
            <LiveBadge loading={loading} />
          </p>
        </div>
        <div className="flex shrink-0 gap-2">
          <Button asChild variant="outline" size="icon" className="border-slate-700 bg-slate-900 hover:bg-slate-800" title="התראות סורק">
            <Link to="/scanner-alerts">
              <Bell className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="icon" className="border-slate-700 bg-slate-900 hover:bg-slate-800" title="סטטוס מערכת">
            <Link to="/system-status">
              <Activity className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="icon" className="border-slate-700 bg-slate-900 hover:bg-slate-800" title="הגדרות תצוגה">
            <Link to="/display-settings">
              <SlidersHorizontal className="h-4 w-4" />
            </Link>
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={onOpenSettings}
            className="border-slate-700 bg-slate-900 hover:bg-slate-800"
            title="מפתחות בורסה"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <ListToggle list={list} onListChange={onListChange} />
        <div className="w-40">
          <Select value={timeframe} onValueChange={onTimeframeChange}>
            <SelectTrigger className="border-slate-700 bg-slate-900">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {TF_LABELS.map((tf) => (
                <SelectItem key={tf.value} value={tf.value}>{tf.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="relative min-w-44 flex-1">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <Input
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="חיפוש מנייה..."
            className="border-slate-700 bg-slate-900 pr-9"
          />
        </div>

        {count > 0 && (
          <span className="text-xs text-slate-500">
            {count} מניות · עודכן ב־{new Date(scannedAt).toLocaleTimeString("he-IL")}
          </span>
        )}
      </div>
    </div>
  );
}
