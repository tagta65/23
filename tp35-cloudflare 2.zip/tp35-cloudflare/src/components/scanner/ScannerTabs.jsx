const TABS = [
  { id: "p402", label: "Protocol 402 + Supply Squeeze" },
  { id: "vixfix", label: "Vix Fix + Momentum + RSI" },
  { id: "analog", label: "Analog UP + MTF" },
  { id: "smc", label: "Algorithm 4 · SMC" },
  { id: "orderflow", label: "Order Flow V2" },
  { id: "mtfflow", label: "MTF Flow PRO" },
  { id: "mrktedge", label: "MRKT EDGE 402" },
];

export default function ScannerTabs({ tab, onTabChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      {TABS.map((t) => (
        <button
          key={t.id}
          onClick={() => onTabChange(t.id)}
          className={
            tab === t.id
              ? "rounded-lg bg-emerald-500 px-3.5 py-2 text-sm font-semibold text-slate-950 shadow-lg shadow-emerald-500/20"
              : "rounded-lg border border-slate-800 bg-slate-900/60 px-3.5 py-2 text-sm text-slate-300 transition-colors hover:border-slate-600"
          }
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}
