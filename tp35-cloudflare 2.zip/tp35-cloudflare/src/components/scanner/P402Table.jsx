import TableShell, { Cell, fmt, NoDataRow } from "./TableShell.jsx";

const HEADERS = ["Symbol", "Price", "Squeeze", "Best Entry", "P402 Status", "TR"];

function squeezeCell(d) {
  if (d.squeezeReady) return { text: "READY", cls: "rounded-md bg-emerald-500 font-bold text-slate-950" };
  if (d.squeezeScore >= 100) return { text: "100%", cls: "rounded-md bg-emerald-500 font-bold text-slate-950" };
  if (d.squeezeScore >= 90) return { text: `${d.squeezeScore}%`, cls: "rounded-md bg-amber-400 font-bold text-slate-950" };
  if (d.squeezeScore >= 80) return { text: `${d.squeezeScore}%`, cls: "rounded-md bg-sky-600 font-bold text-white" };
  return { text: `${d.squeezeScore}%`, cls: "rounded-md bg-slate-700 text-slate-300" };
}

function priceCell(d) {
  if (d.dayChange >= 2 && d.rvol >= 1.5) return "rounded-md bg-[#00c853] font-semibold text-slate-950";
  if (d.dayChange <= -2 && d.rvol >= 1.5) return "rounded-md bg-[#d50000] font-semibold text-white";
  if (d.dayChange > 0) return "rounded-md bg-[#1b5e20] text-white";
  return "rounded-md bg-[#b71c1c] text-white";
}

function p402Cell(d) {
  if (d.distPct <= 1 && d.distPct >= -2) {
    return { text: "BUY ZONE", cls: "rounded-md bg-[#00e676] font-bold text-slate-950" };
  }
  if (d.distPct <= 4) {
    return { text: "NEAR", cls: "rounded-md bg-amber-500 font-bold text-slate-950" };
  }
  return { text: `-${fmt(d.distPct, 1)}%`, cls: "rounded-md bg-slate-700 text-slate-300" };
}

function trendCell(d) {
  if (d.stretched) return { text: "⚠️", cls: "rounded-md bg-[#d50000]" };
  if (d.riding) return { text: "🚀", cls: "rounded-md bg-blue-500" };
  return { text: "—", cls: "rounded-md bg-slate-800 text-slate-500" };
}

export default function P402Table({ results, zoom }) {
  return (
    <TableShell columns={HEADERS} zoom={zoom}>
      {results.map(({ symbol, data }) => {
        if (!data) return <NoDataRow key={symbol} symbol={symbol} cols={6} />;
        const sq = squeezeCell(data);
        const p402 = p402Cell(data);
        const trend = trendCell(data);
        return (
          <tr key={symbol}>
            <Cell className={`${sq.cls}`}>{symbol}</Cell>
            <Cell className={priceCell(data)}>
              {fmt(data.price)}
              <span className="ml-1 text-[10px] opacity-80">{fmt(data.dayChange, 1)}%</span>
            </Cell>
            <Cell className={`${sq.cls}`}>{sq.text}</Cell>
            <Cell className="rounded-md bg-slate-800 text-slate-200">{fmt(data.idealEntry)}</Cell>
            <Cell className={p402.cls}>{p402.text}</Cell>
            <Cell className={trend.cls}>{trend.text}</Cell>
          </tr>
        );
      })}
    </TableShell>
  );
}