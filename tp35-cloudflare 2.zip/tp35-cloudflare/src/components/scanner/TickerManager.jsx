import db from "@/api/localDb";

import React, { useState, useEffect } from "react";
import { Plus, Trash2, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function TickerManager({ onSaved }) {
  const [list, setList] = useState("1");
  const [tickers, setTickers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [symbol, setSymbol] = useState("");
  const [name, setName] = useState("");
  const [status, setStatus] = useState(null);

  const load = async (which) => {
    setLoading(true);
    try {
      await db.seedTickers();
      const recs = await db.entities.Ticker.filter(
        { list: which },
        "-created_date",
        500
      );
      setTickers(recs);
    } catch (e) {
      setStatus({ ok: false, msg: e?.message || "טעינת הרשימה נכשלה" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setStatus(null);
    setSymbol("");
    setName("");
    load(list);
  }, [list]);

  const handleAdd = async () => {
    const sym = symbol.trim().toUpperCase();
    if (!sym) {
      setStatus({ ok: false, msg: "הזן סימול מנייה" });
      return;
    }
    if (tickers.some((t) => t.symbol === sym)) {
      setStatus({ ok: false, msg: "המנייה כבר קיימת ברשימה" });
      return;
    }
    try {
      await db.entities.Ticker.create({
        list,
        symbol: sym,
        name: name.trim() || sym,
      });
      setSymbol("");
      setName("");
      setStatus({ ok: true, msg: `${sym} נוספה לרשימה ${list}` });
      await load(list);
      if (onSaved) onSaved();
    } catch (e) {
      setStatus({ ok: false, msg: e?.message || "ההוספה נכשלה" });
    }
  };

  const handleDelete = async (t) => {
    try {
      await db.entities.Ticker.delete(t.id);
      setTickers((prev) => prev.filter((x) => x.id !== t.id));
      setStatus({ ok: true, msg: `${t.symbol} נמחקה מהרשימה ${list}` });
      if (onSaved) onSaved();
    } catch (e) {
      setStatus({ ok: false, msg: e?.message || "המחיקה נכשלה" });
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <div className="flex overflow-hidden rounded-lg border border-slate-700">
          <button
            onClick={() => setList("1")}
            className={`px-3 py-1.5 text-sm font-medium transition-colors ${
              list === "1"
                ? "bg-slate-100 text-slate-900"
                : "bg-slate-900 text-slate-400 hover:bg-slate-800"
            }`}
          >
            רשימה 1
          </button>
          <button
            onClick={() => setList("2")}
            className={`px-3 py-1.5 text-sm font-medium transition-colors ${
              list === "2"
                ? "bg-slate-100 text-slate-900"
                : "bg-slate-900 text-slate-400 hover:bg-slate-800"
            }`}
          >
            רשימה 2
          </button>
        </div>
        <span className="text-xs text-slate-500">
          {tickers.length} מניות ברשימה
        </span>
      </div>

      <div className="flex gap-2">
        <Input
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          placeholder="סימול (למשל AAPL)"
          className="border-slate-700 bg-slate-950 font-mono"
        />
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAdd()}
          placeholder="שם החברה"
          className="border-slate-700 bg-slate-950"
        />
        <Button
          onClick={handleAdd}
          size="icon"
          className="shrink-0 bg-emerald-500 text-slate-950 hover:bg-emerald-400"
          title="הוסף מנייה"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      {status && (
        <p className={`text-sm ${status.ok ? "text-emerald-400" : "text-red-400"}`}>
          {status.msg}
        </p>
      )}

      <div className="max-h-64 overflow-y-auto rounded-lg border border-slate-800">
        {loading ? (
          <div className="flex items-center justify-center gap-2 py-8 text-slate-400">
            <Loader2 className="h-4 w-4 animate-spin" />
            טוען...
          </div>
        ) : tickers.length ? (
          <ul className="divide-y divide-slate-800">
            {tickers.map((t) => (
              <li
                key={t.id}
                className="flex items-center justify-between gap-2 px-3 py-2"
              >
                <div className="min-w-0">
                  <span className="font-mono text-sm font-medium text-slate-100">
                    {t.symbol}
                  </span>
                  <span className="mr-2 truncate text-xs text-slate-500">
                    {t.name}
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDelete(t)}
                  className="h-8 w-8 shrink-0 text-slate-500 hover:bg-red-950 hover:text-red-400"
                  title={`מחק את ${t.symbol}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="py-8 text-center text-sm text-slate-500">
            אין מניות ברשימה — הוסף כמה
          </p>
        )}
      </div>

      <p className="text-xs text-slate-500">
        השינויים נשמרים בדפדפן הזה ומוחלים בסריקה הבאה.
      </p>
    </div>
  );
}