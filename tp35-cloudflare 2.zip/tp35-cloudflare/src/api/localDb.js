// Browser-only replacement for the Base44 SDK.
// Tickers, Alpaca keys and alerts live in this browser's localStorage.
// Scans / prices go through Netlify Functions, with the visitor's own keys sent per request.
import { TICKERS, TICKERS2 } from "./defaultTickers";

const PREFIX = "tp35:";
const listeners = {};
const SCAN_CACHE_PREFIX = PREFIX + "scan-cache:";
const SCAN_CACHE_TTL = { D: 4 * 60 * 60 * 1000, W: 12 * 60 * 60 * 1000 };

const read = (name) => {
  try {
    return JSON.parse(localStorage.getItem(PREFIX + name) || "[]");
  } catch {
    return [];
  }
};
const write = (name, rows) => {
  try {
    localStorage.setItem(PREFIX + name, JSON.stringify(rows));
  } catch {
    /* storage full / blocked */
  }
};
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

function readScanCache(list, algo, timeframe) {
  const ttl = SCAN_CACHE_TTL[timeframe];
  if (!ttl) return null;
  try {
    const item = JSON.parse(localStorage.getItem(`${SCAN_CACHE_PREFIX}${list}:${algo}:${timeframe}`) || "null");
    if (!item || !item.data || Date.now() - item.cachedAt >= ttl) return null;
    return item.data;
  } catch {
    return null;
  }
}

function writeScanCache(list, algo, timeframe, data) {
  if (!SCAN_CACHE_TTL[timeframe]) return;
  try {
    localStorage.setItem(`${SCAN_CACHE_PREFIX}${list}:${algo}:${timeframe}`, JSON.stringify({ cachedAt: Date.now(), data }));
  } catch {
    /* storage full / blocked */
  }
}

function sortRows(rows, sort) {
  if (!sort) return rows;
  const desc = sort.startsWith("-");
  const key = desc ? sort.slice(1) : sort;
  return [...rows].sort((a, b) => {
    const x = a[key] ?? "";
    const y = b[key] ?? "";
    return (x < y ? -1 : x > y ? 1 : 0) * (desc ? -1 : 1);
  });
}

function matches(row, query = {}) {
  return Object.entries(query).every(([k, v]) => {
    if (v && typeof v === "object" && "$gte" in v) return (row[k] ?? "") >= v.$gte;
    return row[k] === v;
  });
}

function entity(name) {
  const emit = (event) => (listeners[name] || []).forEach((fn) => fn(event));
  return {
    async list(sort, limit) {
      const rows = sortRows(read(name), sort);
      return limit ? rows.slice(0, limit) : rows;
    },
    async filter(query, sort, limit) {
      const rows = sortRows(read(name).filter((r) => matches(r, query)), sort);
      return limit ? rows.slice(0, limit) : rows;
    },
    async create(data) {
      const now = new Date().toISOString();
      const row = { ...data, id: uid(), created_date: now, updated_date: now };
      write(name, [...read(name), row]);
      emit({ type: "create", data: row });
      return row;
    },
    async bulkCreate(items) {
      const out = [];
      for (const item of items) out.push(await this.create(item));
      return out;
    },
    async update(id, patch) {
      let updated = null;
      write(
        name,
        read(name).map((r) =>
          r.id === id ? (updated = { ...r, ...patch, updated_date: new Date().toISOString() }) : r
        )
      );
      return updated;
    },
    async delete(id) {
      write(name, read(name).filter((r) => r.id !== id));
      return {};
    },
    subscribe(fn) {
      (listeners[name] = listeners[name] || []).push(fn);
      return () => {
        listeners[name] = listeners[name].filter((f) => f !== fn);
      };
    },
  };
}

const entities = {
  Ticker: entity("Ticker"),
  AlpacaKeys: entity("AlpacaKeys"),
  ScanAlert: entity("ScanAlert"),
};

// ---- ticker lists (defaults until the user edits them) ----
async function getTickerLists() {
  const recs = await entities.Ticker.filter({});
  if (!recs.length) return { TICKERS, TICKERS2 };
  const pick = (l) => recs.filter((r) => r.list === l).map((r) => ({ symbol: r.symbol, name: r.name }));
  const l1 = pick("1");
  const l2 = pick("2");
  return { TICKERS: l1.length ? l1 : TICKERS, TICKERS2: l2.length ? l2 : TICKERS2 };
}

// First time the ticker manager opens: turn the built-in default lists into real,
// editable records so they can be deleted / replaced like any other ticker.
async function seedTickers() {
  if (read("Ticker").length) return;
  const base = Date.now();
  const rows = [];
  [["1", TICKERS], ["2", TICKERS2]].forEach(([list, arr]) => {
    arr.forEach((t, i) => {
      // newest-first display keeps the original order
      const ts = new Date(base - i).toISOString();
      rows.push({ list, symbol: t.symbol, name: t.name, id: uid(), created_date: ts, updated_date: ts });
    });
  });
  write("Ticker", rows);
}

async function getKeys() {
  const recs = await entities.AlpacaKeys.list("-updated_date", 1);
  return recs[0] || {};
}

// ---- calling Netlify Functions ----
async function callFn(name, body, keys) {
  const res = await fetch(`/api/${name}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-alpaca-key": keys.apiKey || "",
      "x-alpaca-secret": keys.secretKey || "",
    },
    body: JSON.stringify(body),
  });
  let data = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON (e.g. platform timeout page) */
  }
  if (!res.ok) {
    const err = new Error((data && data.error) || `שגיאת שרת ${res.status}`);
    err.response = { data: data || {} };
    throw err;
  }
  return { data };
}

const CHUNK = 6;

async function scanStocks(body, keys, opts = {}) {
  const cached = readScanCache(body.list, body.algo, body.timeframe);
  if (cached) {
    opts.onPartial?.({ data: { ...cached, cached: true } });
    return { data: cached };
  }
  const lists = await getTickerLists();
  const symbols = body.list === "2" ? lists.TICKERS2 : lists.TICKERS;
  const chunks = [];
  for (let i = 0; i < symbols.length; i += CHUNK) chunks.push(symbols.slice(i, i + CHUNK));

  const bySymbol = new Map();
  const candidates = [];
  let lastError = null;
  let okChunks = 0;

  const publish = () => {
    if (!opts.onPartial) return;
    const results = symbols.map(
      (t) => bySymbol.get(t.symbol) || { symbol: t.symbol, name: t.name, data: null, pending: true }
    );
    opts.onPartial({ data: { results, scannedAt: new Date().toISOString(), partial: true } });
  };

  const runChunk = async (chunk) => {
    const { data } = await callFn(
      "scanStocks",
      { algo: body.algo, timeframe: body.timeframe, symbols: chunk },
      keys
    );
    okChunks++;
    candidates.push(...(data.alerts || []));
    for (const r of data.results) bySymbol.set(r.symbol, r);
    publish();
  };

  // 3 chunks in parallel; a failing chunk no longer sinks the whole scan
  const failed = [];
  let next = 0;
  const worker = async () => {
    while (next < chunks.length) {
      const mine = chunks[next++];
      try {
        await runChunk(mine);
      } catch (e) {
        lastError = e;
        if (e.response?.data?.error && /מפתחות/.test(e.response.data.error)) throw e;
        failed.push(mine);
      }
    }
  };
  await Promise.all([worker(), worker(), worker()]);

  // retry failed chunks once, after a short pause (rate limit / cold start hiccups)
  if (failed.length) {
    await new Promise((r) => setTimeout(r, 1200));
    for (const chunk of failed) {
      try {
        await runChunk(chunk);
      } catch (e) {
        lastError = e;
      }
    }
  }
  if (!okChunks && lastError) throw lastError;

  const results = symbols.map(
    (t) => bySymbol.get(t.symbol) || { symbol: t.symbol, name: t.name, data: null }
  );

  // log positive setups as alerts, deduped per symbol within 24h
  try {
    const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
    const algoTf = candidates.length ? candidates[0].timeframe : null;
    if (algoTf) {
      const recent = await entities.ScanAlert.filter({
        algo: body.algo,
        timeframe: algoTf,
        created_date: { $gte: since },
      });
      const seen = new Set(recent.map((a) => a.symbol));
      const fresh = candidates.filter((c) => !seen.has(c.symbol));
      if (fresh.length) await entities.ScanAlert.bulkCreate(fresh);
    }
  } catch {
    /* best-effort */
  }

  const output = { results, scannedAt: new Date().toISOString() };
  writeScanCache(body.list, body.algo, body.timeframe, output);
  return { data: output };
}

const functions = {
  async invoke(name, body = {}, opts = {}) {
    const keys = await getKeys();
    if (!keys.apiKey || !keys.secretKey) {
      const err = new Error("חסרים מפתחות בורסה - פתח את ההגדרות (סמל הגלגל) והזן אותם");
      err.response = { data: { error: err.message } };
      throw err;
    }
    if (name === "scanStocks") return scanStocks(body, keys, opts);
    if (name === "livePrices") {
      const { TICKERS: a, TICKERS2: b } = await getTickerLists();
      const symbols = [...new Set([...a, ...b].map((t) => t.symbol))];
      return callFn("livePrices", { symbols }, keys);
    }
    return callFn(name, body, keys);
  },
};

const db = {
  seedTickers,
  entities,
  functions,
  auth: {
    isAuthenticated: async () => true,
    me: async () => ({ id: "local", role: "admin" }),
  },
};

export default db;
